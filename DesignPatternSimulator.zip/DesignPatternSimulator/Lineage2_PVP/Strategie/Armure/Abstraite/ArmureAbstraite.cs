﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesignPatternSimulator
{
    abstract class ArmureAbstraite
    {
        internal protected String Nom;
        internal protected int PDef;

        public ArmureAbstraite() { }

    }
}
