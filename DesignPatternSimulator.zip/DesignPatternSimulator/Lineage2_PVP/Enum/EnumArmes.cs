﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesignPatternSimulator
{
    enum EnumArme
    {
        Arc,
        Dague,
        Epee,
        DualHache,
        Sceptre,
        Zariche
    };
}
