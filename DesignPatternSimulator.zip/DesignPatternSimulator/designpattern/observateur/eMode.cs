namespace DesignPatternSimulator.designpattern.observateur
{
    public enum eMode
    {

        NON_DEFINI,
        EN_PAIX,
        EN_GUERRE,
        EN_REMPLI,
        AVANCER

    }
}