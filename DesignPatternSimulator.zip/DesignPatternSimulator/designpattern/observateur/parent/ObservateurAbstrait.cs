namespace DesignPatternSimulator.designpattern.observateur.parent
{
	public abstract class ObservateurAbstrait {

		public abstract void update();
	
	}
}