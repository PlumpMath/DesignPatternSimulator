namespace DesignPatternSimulator.designpattern.fabrique.personnage.guerre
{
    //public enum eTypePersonnage
    //{

    //    Indefini,
    //    Archer,
    //    Chevalier,
    //    Fantassin,
    //    Princesse,
    //    Orge
    //}
}