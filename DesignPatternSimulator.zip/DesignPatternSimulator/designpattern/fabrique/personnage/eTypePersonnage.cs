namespace DesignPatternSimulator.designpattern.fabrique.personnage
{
    public enum eTypePersonnage {

	    Indefini,
	    Archer,
	    Chevalier,
	    Fantassin,
	    Princesse,
	    Chef,
	    Soldat,
	    Marine,
        attaquant,
        defenseur,
        milieu,
        gardien,
        PionNoir,
        PionBlanc
    }
}
