namespace DesignPatternSimulator.designpattern.strategie.comportement.guerre.combat.parent
{
	public abstract class ComportementDeCombat {

		public abstract string combattre();
	}
}