namespace DesignPatternSimulator.designpattern.strategie.comportement.guerre.son.parent
{
    public abstract class ComportementEmettreSon
    {
        public abstract string Parler();
    }
}